package producer.eureka.validation.annotation;

public @interface CheckTeacherEmail {
}
